import class_form405

file = input("Please input file name for recognize:")
doc = class_form405.Form405(file)
doc.recognize_image()